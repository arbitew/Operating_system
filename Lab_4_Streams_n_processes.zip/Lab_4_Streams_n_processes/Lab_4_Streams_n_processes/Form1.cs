﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Lab_4_Streams_n_processes
{

    public partial class Form1 : Form
    {
        


        public Form1()
        {
            
            InitializeComponent();
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
        }

        private void timer2_Tick_1(object sender, EventArgs e)
        {

        }
        private void timer3_Tick(object sender, EventArgs e)
        {

        }
        public delegate void MyDelegate();

        void print()
        {
            for (int i = 0; i < 10; i++)
            {
                richTextBox1.Text += "hjkdsfnl";
                /*MessageBox.Show("hjkdsfnl");*/
                //System.Threading.Thread.Sleep(1000);
            }
        }
        void print1()
        {

            for (int i = 0; i < 10; i++)
            {
                /*int a = Convert.ToInt32(richTextBox2.Text);
                */
                richTextBox2.Text += "adsjofk";
                /*MessageBox.Show("adsjofk");*//*
                Thread.Sleep(Convert.ToInt32(900));*/
                //System.Threading.Thread.Sleep(900);
            }
        }   
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            richTextBox1.BeginInvoke(new MyDelegate(print));
            richTextBox2.BeginInvoke(new MyDelegate(print1));
            //var thr1 = new System.Threading.Thread(print);
            //var thr2 = new System.Threading.Thread(print1);
            //thr1.Start(); 

            //thr2.Start();
            //timer1.Enabled = false;
        }
        private void elapcedEvent(object sender, EventArgs e)
        {
            richTextBox1.BeginInvoke(new MyDelegate(print));
        }
        private void elapcedEvent1(object sender, EventArgs e)
        {
            richTextBox2.BeginInvoke(new MyDelegate(print1));
        }
        private void button1_Click(object sender, EventArgs e)
        {
            System.Timers.Timer timer11 = new System.Timers.Timer();
            timer11.Interval = 1000;
            System.Timers.Timer timer21 = new System.Timers.Timer();
            timer21.Interval = 1000;
            timer11.Elapsed += elapcedEvent;
            timer21.Elapsed += elapcedEvent1;
            timer11.Start();
            timer21.Start();
            //timer1.Enabled = true;
        }

        private void Timer21_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
