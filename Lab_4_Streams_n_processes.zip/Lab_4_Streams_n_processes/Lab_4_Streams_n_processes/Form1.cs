﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Lab_4_Streams_n_processes
{

    public partial class Form1 : Form
    {
        void Print()
        {
            for (int i = 0; i < 5; i++)
            {
                richTextBox1.Text = richTextBox1.Text + "2st thread " + i.ToString() + "\n";
                Thread.Sleep(1000);
            }

        }
        void Print1()
        {
            for (int i = 0; i < 5; i++)
            {
                richTextBox1.Text = richTextBox1.Text + "1st thread " + i.ToString() + "\n";
                Thread.Sleep(1000);
            }

        }


        public Form1()
        {
            
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
              
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread thread2 = new Thread(Print);
            thread2.Start();
            Thread thread1 = new Thread(Print1);
            thread2.Start();

        }
    }
}
