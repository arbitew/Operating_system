﻿using Lab_5_ClassLibrary1;
namespace Test_Microsoft
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.Text = "Входит";
            button2.Text = "Выходит";
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button1.Text = "Выходит";
            button2.Text = "Входит";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                a = a * a;
                textBox1.Text = a.ToString();
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                a = a / 2;
                textBox1.Text = a.ToString();
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Lab_5_ClassLibrary1.Class1 Tom = new Lab_5_ClassLibrary1.Class1("Tom");
            button3.Text = Tom.Print_name();
        }
    }
}