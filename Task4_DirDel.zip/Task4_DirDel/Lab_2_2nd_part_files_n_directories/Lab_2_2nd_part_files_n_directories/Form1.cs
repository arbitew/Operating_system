﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab_2_2nd_part_files_n_directories
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }



        private void button4_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != ""))
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string folder_target = File_out_textb.Text;
                        string data;
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_target);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                System.IO.File.Delete(fl);
                            }
                        }
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            System.IO.Directory.Delete(folder_target);
                            MessageBox.Show("You destroyed it:" + folder_target + "\nIt was my lovely directory(");
                        }

                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string folder_source = File_out_textb.Text;
                        System.IO.File.Delete(folder_source);
                        MessageBox.Show("You destroyed it:" + folder_source + "\nIt was my lovely file(");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

    }
    
}
