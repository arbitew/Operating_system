﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8_Registy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistryKey currentUserKey = Registry.CurrentUser;
            RegistryKey helloKey = currentUserKey.CreateSubKey("HelloKey");
            helloKey.SetValue("login", "admin");
            helloKey.SetValue("password", "12345");
            helloKey.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegistryKey currentUserKey = Registry.CurrentUser;
            RegistryKey helloKey = currentUserKey.OpenSubKey("HelloKey", true);
            if(helloKey != null)
            {
                RegistryKey subHelloKey = helloKey.CreateSubKey("SubHelloKey");
                subHelloKey.SetValue("val", "23");
                subHelloKey.Close();
                helloKey.Close();
            }
            else
            {

                MessageBox.Show("doesn't exist");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey currentUserKey = Registry.CurrentUser;
            RegistryKey helloKey = currentUserKey.OpenSubKey("HelloKey");
            if (helloKey != null)
            {

                string login = helloKey.GetValue("login").ToString();
                string password = helloKey.GetValue("password").ToString();
                MessageBox.Show(login);
                MessageBox.Show(password);
                helloKey.Close();
            }
            else
            {
                MessageBox.Show("doesn't exist");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RegistryKey currentUserKey = Registry.CurrentUser;
            RegistryKey helloKey = currentUserKey.OpenSubKey("HelloKey", true);
            if (helloKey != null)
            {
                // удаляем вложенный ключ
                helloKey.DeleteSubKey("SubHelloKey");
                // удаляем значение из ключа
                helloKey.DeleteValue("login");
                helloKey.Close();
                // удаляем сам ключ
                currentUserKey.DeleteSubKey("HelloKey");
                helloKey.Close();
            }
            else
            {
                MessageBox.Show("doesn't exist");
            }
        }   
    }
}
