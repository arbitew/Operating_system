using System.Windows.Forms.Design;

namespace Lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DriveInfo[] d = DriveInfo.GetDrives();
            try
            {//���-�� ������, �� ����� � ���������� ���������� �����
                label1.Text = "Drive: " + d[0].Name + "\nAvalible space" + d[0].AvailableFreeSpace + "\nTotal space" + d[0].TotalSize + "\n";
            }
            catch {
                label1.Text = "DiskError";
            }
            try
            {
                int i = 0;
                foreach (DriveInfo a in d)
                {
                    if (i == 0) { i += 1; continue;}
                    label1.Text = label1.Text + "Drive:" + a.Name + "\nAvalible space" + a.AvailableFreeSpace + "Total space\n" + a.TotalSize + "\n";
                    
                }
            }
            catch {

            }

        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DriveInfo[] d = DriveInfo.GetDrives();
            try
            {//���-�� ������, �� ����� � ���������� ���������� �����
                label1.Text = "Drive: " + d[0].Name + "\nAvalible space: " + d[0].AvailableFreeSpace + "\nTotal space: " + d[0].TotalSize + "\n";
            }
            catch
            {
                label1.Text = "DiskError";
            }
            try
            {
                int i = 0;
                foreach (DriveInfo a in d)
                {
                    if (i == 0) { i += 1; continue; }
                    label1.Text = label1.Text + "Drive:" + a.Name + "\nAvalible space: " + a.AvailableFreeSpace + "\nTotal space: " + a.TotalSize + "\n";
                    //label1.Text = label1.Text + "Drive:" + a.Name + "\nAvalible space: " + Convert.ToInt64(Convert.ToDouble(a.AvailableFreeSpace) / 1024 / 1024) + "\nTotal space: " + Convert.ToInt64(Convert.ToDouble(a.TotalSize)/1024/1024) + "\n";

                }
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string data; 
            string folder_source = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_1";
            string folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2";
            string target_fold;
            if (System.IO.Directory.Exists(folder_source))
            {
                string[] files = System.IO.Directory.GetFiles(folder_source);
                foreach (string fl in files)
                {
                    data = System.IO.Path.GetFileName(fl);
                    target_fold = System.IO.Path.Combine(folder_target, data);
                    System.IO.File.Copy(fl, target_fold, true);
                }

                folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\test_1";
                System.IO.Directory.CreateDirectory(folder_target);
                folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\test_1\\hello.txt";
                System.IO.File.Create(folder_target);
                folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\test_1\\world.txt";
                System.IO.File.Create(folder_target);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\test_1";
            string data;
            if (System.IO.Directory.Exists(folder_target))
            {
                string[] files = System.IO.Directory.GetFiles(folder_target);
                foreach (string fl in files)
                {
                    data = System.IO.Path.GetFileName(fl);
                    System.IO.File.Delete(fl);
                }
            }
            if (System.IO.Directory.Exists(folder_target))
            {
                System.IO.Directory.Delete(folder_target);
            }
            folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_1\\new_text.txt";
            if (System.IO.File.Exists(folder_target))
            {
                System.IO.File.Delete(folder_target);
            }
            folder_target = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\new_text.txt";
            if (System.IO.File.Exists(folder_target))
            {
                System.IO.File.Delete(folder_target);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string folder_source = "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_2\\test\\text.txt";
            string folder_target =  "D:\\����\\Studying\\Course 2\\semester 4\\Operating system\\Lab_1\\Test_folder_1\\new_text.txt";
            if (System.IO.File.Exists(folder_source))
            {
                System.IO.File.Move(folder_source, folder_target);
            }
            else
            {
                System.IO.File.Create(folder_source);
                System.IO.File.Move(folder_source, folder_target);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}