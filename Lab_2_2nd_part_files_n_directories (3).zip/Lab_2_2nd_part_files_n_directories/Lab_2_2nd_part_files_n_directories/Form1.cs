﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab_2_2nd_part_files_n_directories
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File_out_textb.Text != "")
            {
                try
                {
                    System.IO.File.Create(File_out_textb.Text);
                    MessageBox.Show("Smth unknown found:" + File_out_textb.Text);
                }
                catch
                {
                    MessageBox.Show("Rename file or check path");
                }
            }
            else if(Dir_in_textb.Text != "")
            {
                System.IO.Directory.CreateDirectory(Dir_in_textb.Text);
                MessageBox.Show("Smth unknown found:" + Dir_in_textb.Text);
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {            
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != ""))
            {
                if(comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;

                        if (System.IO.Directory.Exists(folder_source))
                        {
                            System.IO.Directory.CreateDirectory(folder_target);
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Copy(fl, target_fold, true);
                            }
                            MessageBox.Show("it copied");
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;
                        System.IO.File.Copy(folder_source, folder_target, true);
                        MessageBox.Show("it copied");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != ""))
            {
                if(comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text + "//" + new_file_name.Text;
                        string target_fold;
                        if (System.IO.Directory.Exists(folder_source))
                        {

                            System.IO.Directory.CreateDirectory(folder_target); 
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Move(fl, target_fold);
                            }
                            System.IO.Directory.Delete(folder_source);
                            MessageBox.Show("it moved");
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;
                        System.IO.File.Move(folder_source, folder_target);
                        MessageBox.Show("it moved");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") || (Dir_in_textb.Text != ""))
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string folder_target = File_out_textb.Text;
                        string data;
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_target);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                System.IO.File.Delete(fl);
                            }
                        }
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            System.IO.Directory.Delete(folder_target);
                            MessageBox.Show("You destroyed it:" + folder_target + "\nIt was my lovely directory(");
                        }

                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string folder_source = File_out_textb.Text;
                        System.IO.File.Delete(folder_source);
                        MessageBox.Show("You destroyed it:" + folder_source + "\nIt was my lovely file(");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != "") && (new_file_name.Text != ""))
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {

                        string old_name = File_out_textb.Text + "\\" + Dir_in_textb.Text;
                        string second_name = File_out_textb.Text + "\\" + new_file_name.Text;
                        System.IO.Directory.CreateDirectory(second_name);
                        string data;
                        string folder_source = old_name;
                        string folder_target = second_name;
                        string target_fold;
                        if (System.IO.Directory.Exists(folder_source))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Move(fl, target_fold);
                            }
                        }
                        System.IO.Directory.Delete(old_name);
                        MessageBox.Show("It was renamed");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string old_name = File_out_textb.Text + "\\" + Dir_in_textb.Text;
                        string second_name = File_out_textb.Text + "\\" + new_file_name.Text;
                        System.IO.File.Move(old_name, second_name);
                        MessageBox.Show("It was renamed");
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void check_but_Click(object sender, EventArgs e)
        {
            if (File_out_textb.Text != "")
            {
                try
                {
                    if (comboBox1.SelectedIndex == 0)
                    {
                        if (System.IO.Directory.Exists(File_out_textb.Text))
                        {
                            MessageBox.Show("Directory exist");
                        }
                        else
                        {
                            MessageBox.Show("Didn't found");
                        }
                        
                    }
                    else if (comboBox1.SelectedIndex == 1)
                    {
                        if (System.IO.File.Exists(File_out_textb.Text))
                        {
                            MessageBox.Show("File exist");
                        }
                        else
                        {
                            MessageBox.Show("Didn't found");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Choose smth in combobox");
                    }
                }
                catch
                {
                    MessageBox.Show("Rename file or check path");
                }
            }
            else
            {

                folderBrowserDialog1.ShowDialog();
            }
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            Process.Start(textOpen.Text, new_file_name.Text);
        }

        private void DirShow_Click(object sender, EventArgs e)
        {
            string[] s;
            if (listBox1.SelectedIndex == -1)
            {
                s = System.IO.Directory.GetDirectories("D:\\РХТУ\\Studying\\Course 2\\semester 4\\Operating system\\Lab_2_2nd_part_files_n_directories");
                Flag.Text = "D:\\РХТУ\\Studying\\Course 2\\semester 4\\Operating system\\Lab_2_2nd_part_files_n_directories";
                listBox1.Items.Clear();
                foreach (string s2 in s)
                {
                    listBox1.Items.Add(s2.Substring(Flag.Text.Length, s2.Length - Flag.Text.Length));
                }
                s = System.IO.Directory.GetFiles("D:\\РХТУ\\Studying\\Course 2\\semester 4\\Operating system\\Lab_2_2nd_part_files_n_directories");
                foreach (string s2 in s)
                {
                    listBox1.Items.Add(s2.Substring(Flag.Text.Length, s2.Length - Flag.Text.Length));
                }
            }
            else
            {
                s = System.IO.Directory.GetDirectories(Flag.Text + listBox1.SelectedItem.ToString());
                string[] s1 = System.IO.Directory.GetFiles(Flag.Text + listBox1.SelectedItem.ToString());
                Flag.Text = Flag.Text + listBox1.SelectedItem.ToString();
                listBox1.Items.Clear();
                foreach (string s2 in s)
                {
                    listBox1.Items.Add(s2.Substring(Flag.Text.Length, s2.Length - Flag.Text.Length));
                }
                foreach (string s2 in s1)
                {
                    listBox1.Items.Add(s2.Substring(Flag.Text.Length, s2.Length - Flag.Text.Length));
                }
            }
            /**/
        }

        private void Flag_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
