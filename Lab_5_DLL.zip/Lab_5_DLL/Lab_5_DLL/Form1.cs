﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyDLL;

using System.Reflection;
using MyDLL;

namespace Lab_5_DLL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*Assembly a = Assembly.Load("MyDLL");
            Object o = a.CreateInstance("Myperson(\"Tom\")");
            Type t = a.GetType("Myperson(\"Tom\")");
            MethodInfo mi = t.GetMethod("name");
            Object[] numbers = new Object[2];
            numbers[0] = "Tom";
            textBox1.Text = Convert.ToString(mi.Invoke(o, numbers));
*/
            MyDLL.Myperson Tom = new MyDLL.Myperson("Tom");
            textBox1.Text = Tom.name();
        }
    }
}
