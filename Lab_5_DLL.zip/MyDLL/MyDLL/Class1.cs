﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDLL
{
    public class Myperson
    {
        string person;
        public Myperson(string person) {
            this.person = person;
        }
        public string name()
        {
            return "Person's name - " + person;
        }
    }
}
