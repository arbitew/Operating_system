﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_6_opened_windows
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool MoveWindow(IntPtr hwd, int X, int Y, int nwidth, int nHeght, bool bRepaint);
        public Form1()
        {
            InitializeComponent();
            Process [] proc = Process.GetProcesses();
            int d = 0;
            foreach (Process p in proc)
            {
                if (!String.IsNullOrEmpty(p.MainWindowTitle))
                {
                    listBox1.Items.Add("Process: " + p.ProcessName + ", ID: " + p.Id + ", Window tile:" + p.MainWindowTitle);
                    //MoveWindow(p.Handle, 60, 53, 355, 235, true); 
                    
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
