﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab_2_2nd_part_files_n_directories
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File_out_textb.Text != "")
            {
                try
                {
                    System.IO.File.Create(File_out_textb.Text);
                }
                catch
                {
                    MessageBox.Show("Rename file or check path");
                }
            }
            else if(Dir_in_textb.Text != "")
            {
                System.IO.Directory.CreateDirectory(Dir_in_textb.Text);
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {            
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != ""))
            {
                if(comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;

                        if (System.IO.Directory.Exists(folder_source))
                        {
                            System.IO.Directory.CreateDirectory(folder_target);
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Copy(fl, target_fold, true);
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;
                        System.IO.File.Copy(folder_source, folder_target, true);
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != ""))
            {
                if(comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;
                        if (System.IO.Directory.Exists(folder_source))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Move(fl, target_fold);
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string data;
                        string folder_source = File_out_textb.Text;
                        string folder_target = Dir_in_textb.Text;
                        string target_fold;
                        System.IO.File.Move(folder_source, folder_target);
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != ""))
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {
                        string folder_target = File_out_textb.Text;
                        string data;
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_target);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                System.IO.File.Delete(fl);
                            }
                        }
                        if (System.IO.Directory.Exists(folder_target))
                        {
                            System.IO.Directory.Delete(folder_target);
                        }

                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string folder_source = File_out_textb.Text;
                        System.IO.File.Delete(folder_source);
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((File_out_textb.Text != "") && (Dir_in_textb.Text != "") && (new_file_name.Text != ""))
            {
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Choose smth in combobox");
                }
                else if (comboBox1.SelectedIndex == 0)
                {

                    try
                    {

                        string old_name = File_out_textb.Text + "\\" + Dir_in_textb.Text;
                        string second_name = File_out_textb.Text + "\\" + new_file_name.Text;
                        System.IO.Directory.CreateDirectory(second_name);
                        string data;
                        string folder_source = old_name;
                        string folder_target = second_name;
                        string target_fold;
                        if (System.IO.Directory.Exists(folder_source))
                        {
                            string[] files = System.IO.Directory.GetFiles(folder_source);
                            foreach (string fl in files)
                            {
                                data = System.IO.Path.GetFileName(fl);
                                target_fold = System.IO.Path.Combine(folder_target, data);
                                System.IO.File.Move(fl, target_fold);
                            }
                        }
                        System.IO.Directory.Delete(old_name);
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        string old_name = File_out_textb.Text + "\\" + Dir_in_textb.Text;
                        string second_name = File_out_textb.Text + "\\" + new_file_name.Text;
                        System.IO.File.Move(old_name, second_name);
                    }
                    catch
                    {
                        MessageBox.Show("Rename file or check path");
                    }
                }
                {

                }
            }
            else
            {
                MessageBox.Show("enter smth in text box");
            }
        }

        private void check_but_Click(object sender, EventArgs e)
        {
            if (File_out_textb.Text != "")
            {
                try
                {
                    if (comboBox1.SelectedIndex == 0)
                    {
                        if (System.IO.Directory.Exists(File_out_textb.Text))
                        {
                            MessageBox.Show("Directory exist");
                        }
                        else
                        {
                            MessageBox.Show("Didn't found");
                        }
                        
                    }
                    else if (comboBox1.SelectedIndex == 1)
                    {
                        if (System.IO.File.Exists(File_out_textb.Text))
                        {
                            MessageBox.Show("File exist");
                        }
                        else
                        {
                            MessageBox.Show("Didn't found");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Choose smth in combobox");
                    }
                }
                catch
                {
                    MessageBox.Show("Rename file or check path");
                }
            }
            else
            {

                folderBrowserDialog1.ShowDialog();
            }
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            Process.Start(textOpen.Text, new_file_name.Text);
        }
    }
}
