﻿namespace Lab_2_2nd_part_files_n_directories
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.File_out_textb = new System.Windows.Forms.TextBox();
            this.Dir_in_textb = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.new_file_name = new System.Windows.Forms.TextBox();
            this.check_but = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.textOpen = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(117, 93);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "Create";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(265, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "Copy";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(393, 93);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 45);
            this.button3.TabIndex = 2;
            this.button3.Text = "Replace";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // File_out_textb
            // 
            this.File_out_textb.Location = new System.Drawing.Point(117, 242);
            this.File_out_textb.Name = "File_out_textb";
            this.File_out_textb.Size = new System.Drawing.Size(216, 22);
            this.File_out_textb.TabIndex = 3;
            // 
            // Dir_in_textb
            // 
            this.Dir_in_textb.Location = new System.Drawing.Point(413, 242);
            this.Dir_in_textb.Name = "Dir_in_textb";
            this.Dir_in_textb.Size = new System.Drawing.Size(218, 22);
            this.Dir_in_textb.TabIndex = 4;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Location = new System.Drawing.Point(0, 475);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(982, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(546, 93);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(85, 45);
            this.button4.TabIndex = 5;
            this.button4.Text = "Delete";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Directory",
            "File"});
            this.comboBox1.Location = new System.Drawing.Point(311, 180);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(334, 316);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 50);
            this.button5.TabIndex = 7;
            this.button5.Text = "Rename";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // new_file_name
            // 
            this.new_file_name.Location = new System.Drawing.Point(486, 330);
            this.new_file_name.Name = "new_file_name";
            this.new_file_name.Size = new System.Drawing.Size(100, 22);
            this.new_file_name.TabIndex = 8;
            // 
            // check_but
            // 
            this.check_but.Location = new System.Drawing.Point(117, 316);
            this.check_but.Name = "check_but";
            this.check_but.Size = new System.Drawing.Size(85, 50);
            this.check_but.TabIndex = 9;
            this.check_but.Text = "Checking";
            this.check_but.UseVisualStyleBackColor = true;
            this.check_but.Click += new System.EventHandler(this.check_but_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(738, 180);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Size = new System.Drawing.Size(150, 100);
            this.splitContainer1.TabIndex = 10;
            // 
            // buttonOpen
            // 
            this.buttonOpen.Location = new System.Drawing.Point(117, 403);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(85, 50);
            this.buttonOpen.TabIndex = 11;
            this.buttonOpen.Text = "button6";
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // textOpen
            // 
            this.textOpen.Location = new System.Drawing.Point(250, 417);
            this.textOpen.Name = "textOpen";
            this.textOpen.Size = new System.Drawing.Size(100, 22);
            this.textOpen.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 497);
            this.Controls.Add(this.textOpen);
            this.Controls.Add(this.buttonOpen);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.check_but);
            this.Controls.Add(this.new_file_name);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.Dir_in_textb);
            this.Controls.Add(this.File_out_textb);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox File_out_textb;
        private System.Windows.Forms.TextBox Dir_in_textb;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox new_file_name;
        private System.Windows.Forms.Button check_but;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.TextBox textOpen;
    }
}

